/* ============================== typing animation ============================ */
var typed = new Typed(".typing",{
    strings:["","Bartender","Waiter","Concierge",""],
    typeSpeed:100,
    BackSpeed:60,
    loop:true
})